import os 
import time

while(True):
    os.system('python fetch_data.py users brandobennitt33 --stop-on-rate-limit')
    time.sleep(960)
